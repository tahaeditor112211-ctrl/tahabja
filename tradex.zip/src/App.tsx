import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Languages, 
  ChevronDown, 
  ShieldCheck,
  User,
  KeyRound,
  ArrowRight,
  Menu,
  X,
  Search
} from 'lucide-react';
import emailjs from "@emailjs/browser";
import Dashboard from './components/Dashboard';
import { auth, db, googleProvider } from './lib/firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  signOut
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { useAuth } from './components/FirebaseProvider';

export default function App() {
  const { user, loading: authLoading } = useAuth();
  
  // ========================================================
  // 🎯 TRADEX LIVE EMAILJS CONNECTION PARAMETERS
  // ========================================================
  const EMAILJS_SERVICE_ID = "service_hayluvm"; 
  const EMAILJS_TEMPLATE_ID = "template_fe01pvc";
  const EMAILJS_PUBLIC_KEY = "3FCpfReNEsxvziq3z";

  useEffect(() => {
    emailjs.init(EMAILJS_PUBLIC_KEY);
  }, []);

  // --- UI Routing States ---
  const [activeTab, setActiveTab] = useState<'signin' | 'register'>('signin');
  const [currentStep, setCurrentStep] = useState<"INPUT_FORM" | "OTP_VERIFICATION" | "DASHBOARD">("INPUT_FORM");
  const [showPassword, setShowPassword] = useState(false);
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLang, setSelectedLang] = useState({ code: "EN", name: "English" });
  const [country, setCountry] = useState("Search");
  const [currency, setCurrency] = useState("USD");
  const [is18Accepted, setIs18Accepted] = useState(false);
  const [isNotUSCitizen, setIsNotUSCitizen] = useState(false);
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [isCurrencyDropdownOpen, setIsCurrencyDropdownOpen] = useState(false);

  const countries = [
    "United Kingdom", "Germany", "France", "Italy", "Spain", "Brazil", "India", "Pakistan", "United Arab Emirates", "Saudi Arabia", "Turkey"
  ];
  const currencies = ["USD", "EUR", "GBP", "JPY"];

  const languages = [
    { code: "EN", name: "English" }, { code: "ES", name: "Español" }, { code: "FR", name: "Français" },
    { code: "DE", name: "Deutsch" }, { code: "IT", name: "Italiano" }, { code: "PT", name: "Português" },
    { code: "RU", name: "Русский" }, { code: "ZH", name: "中文" }, { code: "JA", name: "日本語" },
    { code: "KO", name: "한국어" }, { code: "AR", name: "العربية" }, { code: "HI", name: "हिन्दी" },
    { code: "BN", name: "বাংলা" }, { code: "UR", name: "اردو" }, { code: "TR", name: "Türkçe" },
    { code: "VI", name: "Tiếng Việt" }, { code: "TH", name: "ไทย" }, { code: "ID", name: "Bahasa Indonesia" },
    { code: "MS", name: "Bahasa Melayu" }, { code: "FA", name: "فارسی" }, { code: "PL", name: "Polski" },
    { code: "NL", name: "Nederlands" }, { code: "SV", name: "Svenska" }, { code: "NO", name: "Norsk" },
    { code: "DA", name: "Dansk" }, { code: "FI", name: "Suomi" }, { code: "CS", name: "Čeština" },
    { code: "HU", name: "Magyar" }, { code: "RO", name: "Română" }, { code: "EL", name: "Ελληνικά" },
    { code: "HE", name: "עברית" }, { code: "UK", name: "Українська" }, { code: "BE", name: "Беларуская" },
    { code: "KK", name: "Қазақ тілі" }, { code: "UZ", name: "O'zbekcha" }, { code: "AZ", name: "Azərbaycanca" },
    { code: "KA", name: "ქართული" }, { code: "HY", name: "Հայերեն" }, { code: "AF", name: "Afrikaans" },
    { code: "AM", name: "አማርኛ" }, { code: "SQ", name: "Shqip" }, { code: "AS", name: "অসমীয়া" },
    { code: "AY", name: "Aymar aru" }, { code: "BM", name: "Bamanankan" }, { code: "BS", name: "Bosanski" },
    { code: "BG", name: "Български" }, { code: "CA", name: "Català" }, { code: "CEB", name: "Cebuano" },
    { code: "NY", name: "Chichewa" }, { code: "CO", name: "Corsu" }, { code: "HR", name: "Hrvatski" },
    { code: "DV", name: "ދިވެހިބަސް" }, { code: "EO", name: "Esperanto" }, { code: "ET", name: "Eesti" },
    { code: "EE", name: "Eʋegbe" }, { code: "FIL", name: "Filipino" }, { code: "FY", name: "Frysk" },
    { code: "GL", name: "Galego" }, { code: "GU", name: "ગુજરાતી" }, { code: "HT", name: "Kreyòl Ayisyen" },
    { code: "HA", name: "Hausa" }, { code: "HMN", name: "Hmoob" }, { code: "IS", name: "Íslenska" },
    { code: "IG", name: "Igbo" }, { code: "ILO", name: "Ilokano" }, { code: "GA", name: "Gaeilge" },
    { code: "JV", name: "Jawa" }, { code: "KN", name: "ಕನ್ನಡ" }, { code: "KM", name: "ខ្មែរ" },
    { code: "RW", name: "Kinyarwanda" }, { code: "KRI", name: "Krio" }, { code: "KU", name: "Kurdî" },
    { code: "KY", name: "Кыргызча" }, { code: "LO", name: "ລາວ" }, { code: "LA", name: "Latine" },
    { code: "LV", name: "Latviešu" }, { code: "LN", name: "Lingála" }, { code: "LT", name: "Lietuvių" },
    { code: "LG", name: "Luganda" }, { code: "LB", name: "Lëtzebuergesch" }, { code: "MK", name: "Македонски" },
    { code: "MG", name: "Malagasy" }, { code: "ML", name: "മലയാളം" }, { code: "MT", name: "Malti" },
    { code: "MI", name: "Māori" }, { code: "MR", name: "मराठी" }, { code: "MN", name: "Монгол" },
    { code: "MY", name: "မြန်မာ" }, { code: "NE", name: "नेपाली" }, { code: "OR", name: "ଓଡ଼ିଆ" },
    { code: "OM", name: "Oromoo" }, { code: "PS", name: "پښتو" }, { code: "QU", name: "Runa Simi" },
    { code: "SA", name: "संस्कृतम्" }, { code: "GD", name: "Gàidhlig" }, { code: "ST", name: "Sesotho" },
    { code: "SN", name: "ChiShona" }, { code: "SD", name: "سنڌي" }, { code: "SI", name: "සිංහල" },
    { code: "SK", name: "Slovenčina" }, { code: "SL", name: "Slovenščina" }, { code: "SO", name: "Soomaali" },
    { code: "SU", name: "Basa Sunda" }, { code: "SW", name: "Kiswahili" }, { code: "TG", name: "Тоҷикӣ" },
    { code: "TA", name: "தமிழ்" }, { code: "TT", name: "Татар" }, { code: "TE", name: "తెలుగు" },
    { code: "TI", name: "ትግርኛ" }, { code: "TS", name: "Xitsonga" }, { code: "TK", name: "Türkmençe" },
    { code: "AK", name: "Akan" }, { code: "GN", name: "Guarani" }, { code: "Xh", name: "isiXhosa" },
    { code: "Yi", name: "ייִדיש" }, { code: "Yo", name: "Yorùbá" }, { code: "Zu", name: "isiZulu" }
  ];

  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // --- Form Input Fields States ---
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState(""); 
  const [userOTP, setUserOTP] = useState("");       
  const [generatedOTP, setGeneratedOTP] = useState(""); 

  // --- Status Handling ---
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Sync state with Firebase auth state
  useEffect(() => {
    if (user && currentStep === "INPUT_FORM") {
      setCurrentStep("DASHBOARD");
    }
  }, [user]);

  // ========================================================
  // 📩 WORKFLOW 1: SEND OTP (Gate for Standard Auth)
  // ========================================================
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (activeTab === 'register') {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, "users", userCredential.user.uid), {
          email: email,
          displayName: name || email.split('@')[0],
          balance: 10000,
          createdAt: new Date().toISOString(),
          country: country,
          currency: currency
        });
      } else {
        try {
          await signInWithEmailAndPassword(auth, email, password);
        } catch (err: any) {
          if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
            throw new Error("Phala account register kara ok! Account not found with this email.");
          }
          throw err;
        }
      }

      // OTP Gate UX (Optional skip if you want real persistence to be immediate, 
      // but user seems to like the OTP flow too)
      const cryptoOTP = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOTP(cryptoOTP);

      const templateParams = {
        to_email: email.trim(),
        to_name: activeTab === 'signin' ? "Tradex Trader" : (name.trim() || email.split('@')[0]),
        otp_code: cryptoOTP, 
      };

      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams);
      setLoading(false);
      setCurrentStep("OTP_VERIFICATION");
    } catch (err: any) {
      setError(err.message || "Authentication failed");
      setLoading(false);
    }
  };

  // ========================================================
  // 🔥 DYNAMIC NODE: GOOGLE ONE-CLICK AUTH (BYPASS OTP)
  // ========================================================
  const handleGoogleLogin = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const userDoc = await getDoc(doc(db, "users", result.user.uid));
      
      if (!userDoc.exists()) {
        // If they are on the LOGIN tab, don't allow registration via Google
        if (activeTab === 'signin') {
          await signOut(auth); // Sign them out because the account doesn't "exist" in our records
          throw new Error("Account not found. Please register first before using Google Login.");
        }

        // If they are on REGISTER tab, allow creating account with Google
        await setDoc(doc(db, "users", result.user.uid), {
          email: result.user.email,
          displayName: result.user.displayName,
          balance: 10000,
          createdAt: new Date().toISOString(),
          country: "Search", // Default or detect
          currency: "USD"
        });
      }
      
      // DIRECT BYPASS TO DASHBOARD
      setCurrentStep("DASHBOARD");
    } catch (err: any) {
      setError(err.message || "Google login failed");
      await signOut(auth); // Clean up if failed
    } finally {
      setLoading(false);
    }
  };

  // ========================================================
  // 🔑 WORKFLOW 2: VERIFY OTP
  // ========================================================
  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (userOTP === generatedOTP && userOTP !== "") {
      setTimeout(() => {
        setLoading(false);
        setCurrentStep("DASHBOARD");
      }, 800);
    } else {
      setError("Invalid verification code! Please check your Gmail Inbox.");
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setCurrentStep("INPUT_FORM");
    setEmail("");
    setName("");
    setPassword("");
    setUserOTP("");
    setGeneratedOTP("");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-panel">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (currentStep === "DASHBOARD") {
    return (
      <AnimatePresence mode="wait">
        <motion.div
          key="dashboard"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="w-full"
        >
          <Dashboard onLogout={handleLogout} />
        </motion.div>
      </AnimatePresence>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-start font-body text-on-surface antialiased overflow-x-hidden selection:bg-primary-container selection:text-on-primary-fixed">
      {/* Header */}
      <header className="w-full h-16 bg-[#0b0e11]/80 backdrop-blur-md border-b border-white/5 fixed top-0 z-[100] px-gutter flex items-center justify-between">
        <div className="flex items-center gap-stack-lg">
          <div className="flex items-center gap-4">
            <img 
              src="/src/assets/images/tradex_logo_final_blackbg_1779041950018.png" 
              alt="Tradex Logo" 
              className="w-14 h-14 object-contain mix-blend-screen"
              referrerPolicy="no-referrer"
            />
            <div className="flex flex-col">
              <h1 className="font-headline text-[24px] text-primary-container font-black uppercase tracking-tighter leading-none">TRADEX</h1>
              <span className="text-[10px] text-on-surface-variant font-bold tracking-[0.2em] -mt-0.5 uppercase opacity-60">Next-Gen Broker</span>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-stack-md ml-stack-lg">
            {['Trading', 'Market', 'Support'].map(item => (
              <a key={item} href="#" className="font-body text-[10px] font-bold text-on-surface-variant hover:text-primary transition-colors uppercase tracking-[0.2em]">{item}</a>
            ))}
          </nav>
        </div>
        
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={() => setIsLangModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded transition-colors group"
          >
            <Languages className="w-4 h-4 text-on-surface-variant group-hover:text-primary transition-colors" />
            <span className="font-bold text-[10px] text-on-surface-variant uppercase">{selectedLang.code}</span>
            <ChevronDown className="w-3 h-3 text-on-surface-variant/40" />
          </button>

          <button 
            onClick={() => { setActiveTab('signin'); setCurrentStep('INPUT_FORM'); }}
            className="hidden sm:block px-6 py-2 bg-primary-container text-on-primary-fixed hover:brightness-110 rounded font-bold text-[10px] uppercase tracking-widest transition-all shadow-[0_0_15px_rgba(240,185,11,0.2)]"
          >
            Get Started
          </button>
          
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 hover:bg-white/5 rounded transition-colors"
          >
            <Menu className="w-6 h-6 text-on-surface-variant" />
          </button>
        </div>
      </header>

      {/* Language Modal */}
      <AnimatePresence>
        {isLangModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-surface-container-low border border-white/5 w-full max-w-2xl h-[80vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <h3 className="font-headline font-bold text-lg uppercase tracking-widest text-primary">Select Language</h3>
                <button onClick={() => setIsLangModalOpen(false)} className="p-2 hover:bg-white/5 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-4 bg-black/20">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
                  <input 
                    type="text"
                    placeholder="Search languages (100+ available)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-surface-container-highest border border-white/5 rounded-xl py-3 pl-10 pr-4 font-body focus:outline-none focus:border-primary/50 transition-colors"
                  />
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-white/10">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {filteredLanguages.map((lang) => (
                    <button 
                      key={lang.code}
                      onClick={() => { setSelectedLang(lang); setIsLangModalOpen(false); }}
                      className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                        selectedLang.code === lang.code 
                        ? 'bg-primary/20 border-primary text-primary' 
                        : 'bg-white/5 border-transparent hover:border-white/10 text-on-surface-variant hover:text-white'
                      }`}
                    >
                      <span className="font-medium">{lang.name}</span>
                      <span className="text-[10px] font-bold opacity-40">{lang.code}</span>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm sm:hidden"
            />
            <motion.div 
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-[280px] bg-[#0b0e11] border-l border-white/5 z-[151] p-6 flex flex-col sm:hidden"
            >
              <div className="flex justify-between items-center mb-8">
                <span className="font-headline font-black text-primary text-xl uppercase tracking-tighter">MENU</span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 hover:bg-white/5 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <nav className="flex flex-col gap-4">
                <button 
                  onClick={() => { setActiveTab('signin'); setCurrentStep('INPUT_FORM'); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-3 p-4 bg-white/5 hover:bg-white/10 rounded-xl transition-colors font-bold uppercase tracking-widest text-sm"
                >
                  <User className="w-5 h-5 text-primary" />
                  Login
                </button>
                <button 
                  onClick={() => { setActiveTab('register'); setCurrentStep('INPUT_FORM'); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-3 p-4 bg-primary-container text-on-primary-fixed rounded-xl font-bold uppercase tracking-widest text-sm shadow-lg"
                >
                  <ArrowRight className="w-5 h-5" />
                  Get Started
                </button>
                
                <div className="h-[1px] bg-white/5 my-4"></div>

                {[
                  'Trading Rules', 'Risk Disclosure', 'Privacy Policy', 'Contact Support'
                ].map((item) => (
                  <a key={item} href="#" className="p-4 font-bold text-on-surface-variant hover:text-white uppercase tracking-widest text-[12px] transition-colors">
                    {item}
                  </a>
                ))}
              </nav>

              <div className="mt-auto">
                 <button 
                  onClick={() => { setIsLangModalOpen(true); setIsMobileMenuOpen(false); }}
                  className="w-full flex items-center justify-between p-4 bg-surface-container-highest rounded-xl border border-white/5"
                 >
                   <div className="flex items-center gap-3">
                     <Languages className="w-5 h-5 text-primary" />
                     <span className="font-bold text-sm">{selectedLang.name}</span>
                   </div>
                   <ChevronDown className="w-4 h-4 text-white/40" />
                 </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Subtle Golden Background Glow & Trading Chart Pattern */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden bg-[#0b0e11]">
        {/* Trading Chart Pattern Layer (Enhanced visibility to ~10% for clarity) */}
        <div 
          className="absolute inset-0 opacity-[0.1]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='300' height='300' viewBox='0 0 300 300' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 220 L40 180 L80 200 L120 120 L160 160 L200 40 L240 100 L300 80' fill='none' stroke='%23f0b90b' stroke-width='2'/%3E%3Crect x='35' y='180' width='10' height='40' fill='%23ff4d4d'/%3E%3Crect x='75' y='160' width='10' height='60' fill='%2300c076'/%3E%3Crect x='115' y='110' width='10' height='40' fill='%23ff4d4d'/%3E%3Crect x='155' y='90' width='10' height='100' fill='%2300c076'/%3E%3Crect x='195' y='40' width='10' height='60' fill='%23ff4d4d'/%3E%3Crect x='235' y='80' width='10' height='40' fill='%2300c076'/%3E%3C/svg%3E")`,
            backgroundSize: '300px 300px'
          }}
        />
        <motion.div 
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full bg-primary/10 blur-[120px]"
        />
      </div>

      {/* Main Content Shell */}
      <main className="relative z-10 w-full max-w-[1240px] px-gutter pt-32 pb-stack-lg flex-1 flex items-center">
        <div className="grid lg:grid-cols-2 gap-stack-lg items-center w-full">
          
          {/* Branding/Value Prop Side (Left - Desktop Only) */}
          <div className="hidden lg:flex flex-col space-y-stack-lg pr-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-stack-sm"
            >
              <h2 className="font-headline text-[48px] text-white leading-[1.1] font-black italic tracking-tighter">
                Secure Gateway to <span className="text-primary-container">Next-Gen</span> Binary Trading.
              </h2>
              <p className="font-body text-[16px] text-on-surface-variant/80 max-w-md leading-relaxed">
                Experience professional-grade execution speeds, industry-leading security protocols, and 24/7 global market access.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="grid grid-cols-2 gap-stack-md"
            >
              {[
                { icon: <ShieldCheck className="w-5 h-5 text-primary" />, title: "GLOBAL REACH", desc: "Active in 150+ countries with low-latency nodes." },
                { icon: <ShieldCheck className="w-5 h-5 text-primary" />, title: "FULLY REGULATED", desc: "Compliant with international security standards." }
              ].map((item, idx) => (
                <div key={idx} className="p-stack-md bg-white/[0.03] border border-white/5 rounded-xl backdrop-blur-sm group hover:bg-white/[0.05] transition-all">
                  <div className="mb-2">{item.icon}</div>
                  <h4 className="font-body text-[11px] font-black text-white mb-1 uppercase tracking-widest">{item.title}</h4>
                  <p className="font-body text-[12px] text-on-surface-variant/60 leading-tight">{item.desc}</p>
                </div>
              ))}
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              transition={{ delay: 0.6 }}
              className="flex items-center gap-stack-md grayscale hover:grayscale-0 transition-all cursor-default"
            >
              {['SECURE_CERT_01', 'COMPLIANCE_2024', 'FAST_PAY_VERIFIED'].map(tag => (
                <div key={tag} className="text-[9px] font-bold text-white border border-white/20 px-3 py-1 rounded uppercase tracking-widest">{tag}</div>
              ))}
            </motion.div>
          </div>

      {/* Auth Form Card Side (Right) */}
          <div className="w-full max-w-[480px] mx-auto lg:ml-auto lg:mr-0">
            {/* Auth Modal Card */}
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-panel border border-slate-border rounded-2xl p-8 sm:p-10 shadow-2xl backdrop-blur-md relative"
            >
              {/* Branding Header (Visible on Mobile) */}
              <div className="lg:hidden text-center mb-10">
                <h1 className="font-headline text-[48px] text-primary-container uppercase tracking-tighter leading-none mb-2 font-black italic">
                  TRADEX
                </h1>
                <p className="font-body text-[11px] font-bold text-on-surface-variant tracking-[0.3em] uppercase opacity-60">
                  {activeTab === 'signin' ? 'Login To Your Account' : 'Register New Account'}
                </p>
              </div>

              <div className="text-center hidden lg:block mb-8">
                <h2 className="font-headline text-3xl text-white font-bold mb-2">
                  {activeTab === 'signin' ? 'Authorize Login' : 'Create Account'}
                </h2>
                <p className="font-body text-[11px] text-on-surface-variant/40 uppercase tracking-widest font-bold font-black">
                  {activeTab === 'signin' ? 'Secure Terminal Link' : 'Secure Registration Gateway'}
                </p>
              </div>

          <AnimatePresence mode="wait">
            {currentStep === 'INPUT_FORM' ?
              <motion.div
                key="form-step"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                {/* Tabs Switcher */}
                <div className="flex border-b border-slate-border mb-stack-lg">
                  <button 
                    type="button"
                    onClick={() => { setActiveTab('signin'); setError(""); }}
                    className={`flex-1 pb-stack-sm font-body text-[12px] font-bold tracking-widest transition-all relative ${
                      activeTab === 'signin' ? 'text-primary' : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    LOGIN
                    {activeTab === 'signin' && (
                      <motion.div 
                        layoutId="tab-indicator"
                        className="absolute bottom-0 left-0 right-0 h-[2px] bg-primary"
                      />
                    )}
                  </button>
                  <button 
                    type="button"
                    onClick={() => { setActiveTab('register'); setError(""); }}
                    className={`flex-1 pb-stack-sm font-body text-[12px] font-bold tracking-widest transition-all relative ${
                      activeTab === 'register' ? 'text-primary' : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    REGISTER
                    {activeTab === 'register' && (
                      <motion.div 
                        layoutId="tab-indicator"
                        className="absolute bottom-0 left-0 right-0 h-[2px] bg-primary"
                      />
                    )}
                  </button>
                </div>

                {error && (
                  <div className="mb-4 p-3 rounded bg-red-500/10 border border-red-500/20 text-red-500 text-[11px] font-bold uppercase tracking-wider">
                    ⚠ {error}
                  </div>
                )}

                <form className="space-y-4" onSubmit={handleFormSubmit}>
                  {activeTab === 'register' ? (
                    <>
                      {/* Country Select */}
                      <div className="space-y-1 relative">
                        <label className="block text-[11px] font-bold text-on-surface-variant/60 uppercase tracking-widest">Country / Region of residence</label>
                        <button 
                          type="button"
                          onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                          className="w-full bg-[#1e2329] border border-white/5 rounded-lg px-4 py-3 text-left flex items-center justify-between group hover:border-white/20 transition-all"
                        >
                          <div className="flex items-center gap-3">
                            <Search className="w-4 h-4 text-on-surface-variant/40" />
                            <span className="text-on-surface-variant">{country}</span>
                          </div>
                          <ChevronDown className={`w-4 h-4 text-on-surface-variant/40 transition-transform ${isCountryDropdownOpen ? 'rotate-180' : ''}`} />
                        </button>
                        
                        <AnimatePresence>
                          {isCountryDropdownOpen && (
                            <motion.div 
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="absolute z-50 top-full left-0 right-0 mt-2 bg-[#1e2329] border border-white/5 rounded-lg shadow-2xl max-h-[200px] overflow-y-auto"
                            >
                              {countries.map(c => (
                                <button 
                                  key={c}
                                  type="button"
                                  onClick={() => { setCountry(c); setIsCountryDropdownOpen(false); }}
                                  className="w-full text-left px-4 py-2 hover:bg-white/5 text-[13px] text-on-surface-variant transition-colors"
                                >
                                  {c}
                                </button>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Currency Select */}
                      <div className="space-y-1 relative">
                        <label className="block text-[11px] font-bold text-on-surface-variant/60 uppercase tracking-widest">Currency</label>
                        <button 
                          type="button"
                          onClick={() => setIsCurrencyDropdownOpen(!isCurrencyDropdownOpen)}
                          className="w-full bg-[#1e2329] border border-white/5 rounded-lg px-4 py-3 text-left flex items-center justify-between group hover:border-white/20 transition-all"
                        >
                          <span className="text-on-surface font-black">{currency}</span>
                          <ChevronDown className={`w-4 h-4 text-on-surface-variant/40 transition-transform ${isCurrencyDropdownOpen ? 'rotate-180' : ''}`} />
                        </button>
                        
                        <AnimatePresence>
                          {isCurrencyDropdownOpen && (
                            <motion.div 
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="absolute z-50 top-full left-0 right-0 mt-2 bg-[#1e2329] border border-white/5 rounded-lg shadow-2xl"
                            >
                              {currencies.map(curr => (
                                <button 
                                  key={curr}
                                  type="button"
                                  onClick={() => { setCurrency(curr); setIsCurrencyDropdownOpen(false); }}
                                  className="w-full text-left px-4 py-2 hover:bg-white/5 text-[13px] text-on-surface-variant transition-colors"
                                >
                                  {curr}
                                </button>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Email Field - Register */}
                      <div className="space-y-1">
                        <label className="block text-[11px] font-bold text-on-surface-variant/60 uppercase tracking-widest">Email</label>
                        <input 
                          type="email" 
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-[#1e2329] border border-white/5 rounded-lg px-4 py-3 text-on-surface placeholder:text-on-surface-variant/20 focus:outline-none focus:border-primary/50 transition-all"
                        />
                      </div>

                      {/* Password Field - Register */}
                      <div className="space-y-1">
                        <label className="block text-[11px] font-bold text-on-surface-variant/60 uppercase tracking-widest">Password</label>
                        <div className="relative group">
                          <input 
                            type={showPassword ? "text" : "password"} 
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-[#1e2329] border border-white/5 rounded-lg px-4 py-3 text-on-surface placeholder:text-on-surface-variant/20 focus:outline-none focus:border-primary/50 transition-all"
                          />
                          <button 
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 transition-colors hover:text-primary"
                          >
                            {showPassword ? <EyeOff className="w-5 h-5 text-on-surface-variant/40" /> : <Eye className="w-5 h-5 text-on-surface-variant/40" />}
                          </button>
                        </div>
                      </div>

                      {/* Checkboxes */}
                      <div className="space-y-4 pt-2">
                        <label className="flex items-start gap-4 cursor-pointer group">
                          <input 
                            type="checkbox" 
                            required
                            checked={is18Accepted}
                            onChange={(e) => setIs18Accepted(e.target.checked)}
                            className="mt-1 w-5 h-5 rounded border-white/10 bg-[#1e2329] text-primary focus:ring-offset-0 focus:ring-0 cursor-pointer"
                          />
                          <span className="text-[13px] text-on-surface-variant/80 leading-tight">
                            I confirm that I am 18 years old or older and accept <span className="text-[#3d9bff] hover:underline">Service Agreement</span>
                          </span>
                        </label>

                        <label className="flex items-start gap-4 cursor-pointer group">
                          <input 
                            type="checkbox" 
                            required
                            checked={isNotUSCitizen}
                            onChange={(e) => setIsNotUSCitizen(e.target.checked)}
                            className="mt-1 w-5 h-5 rounded border-white/10 bg-[#1e2329] text-primary focus:ring-offset-0 focus:ring-0 cursor-pointer"
                          />
                          <span className="text-[13px] text-on-surface-variant/80 leading-tight">
                            I declare and confirm that I am not a citizen or resident of the US for tax purposes
                          </span>
                        </label>
                      </div>

                      <button 
                        disabled={loading || !is18Accepted || !isNotUSCitizen}
                        className="w-full bg-primary-container text-on-primary-fixed font-black text-[18px] py-4 rounded-xl flex items-center justify-center gap-3 hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(240,185,11,0.3)] disabled:opacity-50 mt-6"
                      >
                        {loading ? "Registration..." : "Registration"}
                        <ArrowRight className="w-6 h-6 p-1 bg-white/20 rounded-full" />
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="space-y-unit">
                        <label className="block font-body text-[12px] font-bold text-on-surface-variant uppercase tracking-wider">Secure Email Address</label>
                        <div className="relative group">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant group-focus-within:text-primary-container transition-colors" />
                          <input 
                            type="email" 
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-surface-container-lowest border border-slate-border rounded px-10 py-3 font-body text-[16px] text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary-container transition-all"
                            placeholder="name@gmail.com"
                          />
                        </div>
                      </div>

                      <div className="space-y-unit">
                        <div className="flex justify-between items-center">
                          <label className="block font-body text-[12px] font-bold text-on-surface-variant uppercase tracking-wider">Cryptographic Password</label>
                          <button type="button" className="font-body text-[10px] font-bold text-primary-container hover:underline uppercase">Forgot?</button>
                        </div>
                        <div className="relative group">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant group-focus-within:text-primary-container transition-colors" />
                          <input 
                            type={showPassword ? "text" : "password"} 
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-surface-container-lowest border border-slate-border rounded px-10 py-3 font-body text-[16px] text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary-container transition-all"
                            placeholder="••••••••••••"
                          />
                          <button 
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 transition-colors hover:text-primary"
                          >
                            {showPassword ? <EyeOff className="w-5 h-5 text-on-surface-variant" /> : <Eye className="w-5 h-5 text-on-surface-variant" />}
                          </button>
                        </div>
                      </div>

                      <button 
                        disabled={loading}
                        className="w-full bg-primary-container text-on-primary-fixed font-body text-[14px] font-extrabold py-[14px] rounded uppercase tracking-widest hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(240,185,11,0.2)] disabled:opacity-50"
                      >
                        {loading ? "SENDING GMAIL OTP..." : 'AUTHORIZE ACCESS'}
                      </button>
                    </>
                  )}
                </form>
              </motion.div>
            : 
              <motion.div
                key="otp-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-stack-md"
              >
                <div className="text-center space-y-unit mb-stack-md">
                   <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                      <KeyRound className="w-6 h-6" />
                   </div>
                   <h2 className="text-[18px] font-headline font-bold text-primary uppercase tracking-tight">GMAIL CODE REQUIRED</h2>
                   <p className="text-[12px] text-on-surface-variant max-w-[280px] mx-auto">
                     We sent a 6-digit authentication token to <span className="text-primary">{email}</span>.
                   </p>
                </div>

                {error && (
                  <div className="p-3 rounded bg-red-500/10 border border-red-500/20 text-red-500 text-[11px] font-bold text-center">
                    ⚠ {error}
                  </div>
                )}

                <form onSubmit={handleVerifyOTP} className="space-y-stack-md">
                   <input 
                    type="text" 
                    required
                    maxLength={6}
                    value={userOTP}
                    onChange={(e) => setUserOTP(e.target.value)}
                    placeholder="000000"
                    className="w-full bg-surface-container-lowest border border-slate-border tracking-[0.5em] text-center font-mono font-bold rounded px-4 py-4 text-[24px] text-primary cursor-pointer focus:outline-none focus:border-primary transition-all"
                  />
                  <button 
                    disabled={loading}
                    className="w-full bg-primary-container text-on-primary-fixed font-body text-[14px] font-extrabold py-4 rounded uppercase tracking-widest hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(240,185,11,0.2)] flex items-center justify-center gap-2"
                  >
                    {loading ? "VERIFYING..." : "VERIFY AND ENTER"}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  
                  <button 
                    type="button"
                    onClick={() => setCurrentStep('INPUT_FORM')}
                    className="w-full text-[11px] text-on-surface-variant hover:text-primary font-bold uppercase tracking-widest text-center"
                  >
                    Back to login
                  </button>
                </form>
              </motion.div>
            }
          </AnimatePresence>

          {/* Social Auth */}
          <div className="relative my-stack-lg flex items-center">
            <div className="flex-grow border-t border-slate-border/50"></div>
            <span className="flex-shrink mx-4 font-body text-[9px] font-bold text-on-surface-variant/40 uppercase tracking-[0.3em]">Quick Access</span>
            <div className="flex-grow border-t border-slate-border/50"></div>
          </div>

          <div className="flex justify-center">
            <button 
              onClick={handleGoogleLogin}
              disabled={loading}
              className="group relative flex items-center justify-center bg-surface-container-high border border-slate-border rounded-xl w-16 h-16 hover:bg-surface-container-highest hover:border-primary/30 transition-all duration-300 disabled:opacity-50 shadow-lg"
              title="Secure Login with Google"
            >
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center p-1 shadow-sm group-hover:scale-110 transition-transform">
                <img 
                  src="/src/assets/images/google_custom_login_logo_png_1779043148536.png" 
                  alt="Google" 
                  className="w-full h-full object-contain"
                />
              </div>
              
              {/* Subtle Glow Overlay */}
              <div className="absolute inset-0 rounded-xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              
              {loading && (
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
                   <span className="font-body text-[8px] font-bold text-primary uppercase tracking-widest animate-pulse">Verifying...</span>
                </div>
              )}
            </button>
          </div>
        </motion.section>

        {/* Trust Indicator */}
        <div className="mt-stack-xl text-center flex flex-col items-center gap-unit">
          <div className="flex items-center gap-unit text-primary/40">
            <ShieldCheck className="w-3 h-3" />
            <span className="font-body text-[9px] font-bold uppercase tracking-[0.2em]">End-to-End Encrypted Gateway</span>
          </div>
        </div>
      </div>
    </div>
  </main>

      {/* Footer */}
      <footer className="relative z-20 w-full border-t border-slate-border bg-[#0b0e11] py-stack-lg mt-auto">
        <div className="max-w-[1440px] mx-auto px-container-padding">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-stack-lg pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <img 
                  src="/src/assets/images/tradex_logo_final_blackbg_1779041950018.png" 
                  alt="Tradex Logo" 
                  className="w-10 h-10 object-contain mix-blend-screen"
                  referrerPolicy="no-referrer"
                />
                <div className="font-headline text-primary-container font-black tracking-widest text-[16px]">TRADEX</div>
              </div>
              <div className="font-body text-[9px] text-on-surface-variant font-bold tracking-[0.2em] uppercase opacity-60">
                © 2024 TRADEX. NEXT-GEN BINARY BROKER.
              </div>
            </div>
            
            <div className="flex flex-wrap gap-x-stack-lg gap-y-stack-sm">
              {[
                'Terms of Service', 'Privacy Policy', 'Risk Disclosure', 'Security'
              ].map((item) => (
                <a key={item} href="#" className="font-body text-[10px] font-bold text-on-surface-variant hover:text-primary transition-colors uppercase tracking-[0.2em]">
                  {item}
                </a>
              ))}
            </div>
          </div>
          
          <div className="pt-6 border-t border-slate-border/30">
            <p className="font-body text-[10px] text-on-surface-variant/40 leading-relaxed uppercase tracking-wider text-justify">
              Risk Warning: Trading binary options involves high risk and may not be suitable for all investors. The potential exists to lose all of your initial investment. Ensure you fully understand the risks before participating in any trading activity.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
