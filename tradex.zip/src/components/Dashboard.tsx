import { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Settings, 
  LogOut, 
  History, 
  LayoutDashboard,
  Bell,
  Search,
  ChevronUp,
  ChevronDown,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip,
  CartesianGrid 
} from 'recharts';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  doc, 
  onSnapshot, 
  updateDoc, 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  limit, 
  serverTimestamp,
  type Timestamp
} from 'firebase/firestore';

// Mock chart data
const generateData = () => {
  const data = [];
  let basePrice = 1.0850;
  for (let i = 0; i < 30; i++) {
    basePrice += (Math.random() - 0.5) * 0.002;
    data.push({
      time: `${12 + Math.floor(i/2)}:${(i%2)*30 || '00'}`,
      price: parseFloat(basePrice.toFixed(4))
    });
  }
  return data;
};

const assets = [
  { id: 'eurusd', name: 'EUR/USD', price: '1.0854', change: '+0.12%', trend: 'up' },
  { id: 'btcusd', name: 'BTC/USD', price: '64,240', change: '-1.45%', trend: 'down' },
  { id: 'gold', name: 'GOLD', price: '2,314', change: '+0.54%', trend: 'up' },
  { id: 'ethusd', name: 'ETH/USD', price: '3,450', change: '-0.32%', trend: 'down' },
];

interface DashboardProps {
  onLogout: () => void;
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const [data, setData] = useState(generateData());
  const [amount, setAmount] = useState('100');
  const [duration, setDuration] = useState('1m');
  const [selectedAsset, setSelectedAsset] = useState(assets[0]);
  
  // Firestore State
  const [userData, setUserData] = useState<any>(null);
  const [recentTrades, setRecentTrades] = useState<any[]>([]);
  const [executing, setExecuting] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;

    // Listen to User Profile
    const userRef = doc(db, 'users', auth.currentUser.uid);
    const unsubscribeUser = onSnapshot(userRef, (snapshot) => {
      setUserData(snapshot.data());
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}`);
    });

    // Listen to Recent Trades
    const tradesRef = collection(db, 'users', auth.currentUser.uid, 'trades');
    const q = query(tradesRef, orderBy('timestamp', 'desc'), limit(10));
    const unsubscribeTrades = onSnapshot(q, (snapshot) => {
      const trades = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRecentTrades(trades);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}/trades`);
    });

    return () => {
      unsubscribeUser();
      unsubscribeTrades();
    };
  }, []);

  const handleTrade = async (tradeType: 'CALL' | 'PUT') => {
    if (!auth.currentUser || !userData) return;
    const investAmount = parseFloat(amount);
    if (isNaN(investAmount) || investAmount <= 0) return;
    if (investAmount > userData.balance) return;

    setExecuting(true);
    try {
      const profitRate = 0.86;
      const isWin = Math.random() > 0.45; // Real trade logic would be server-side
      const profit = isWin ? investAmount * profitRate : -investAmount;
      const status = isWin ? 'win' : 'loss';

      const tradeData = {
        userId: auth.currentUser.uid,
        assetName: selectedAsset.name,
        type: tradeType,
        amount: investAmount,
        profit: profit,
        status: status,
        duration: duration,
        timestamp: serverTimestamp()
      };

      // 1. Add Trade Record
      await addDoc(collection(db, 'users', auth.currentUser.uid, 'trades'), tradeData);

      // 2. Update Balance
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        balance: userData.balance + profit
      });

    } catch (err) {
      console.error("Trade Error:", err);
    } finally {
      setExecuting(false);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const last = prev[prev.length - 1];
        const newPrice = parseFloat((last.price + (Math.random() - 0.5) * 0.001).toFixed(4));
        return [...prev.slice(1), { time: 'Now', price: newPrice }];
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-surface-container-lowest flex flex-col font-body">
      {/* Top Navbar */}
      <header className="h-16 bg-surface-container-low border-b border-slate-border flex items-center justify-between px-gutter sticky top-0 z-50">
        <div className="flex items-center gap-stack-lg">
          <div className="flex items-center gap-unit">
            <img 
              src="/src/assets/images/tradex_logo_final_blackbg_1779041950018.png" 
              alt="Tradex Logo" 
              className="w-12 h-12 object-contain mix-blend-screen"
              referrerPolicy="no-referrer"
            />
            <span className="font-headline text-[24px] font-extrabold text-primary-container tracking-tighter">TRADEX</span>
          </div>
          
          <nav className="hidden md:flex items-center gap-stack-md text-[13px] font-bold tracking-wider text-on-surface-variant">
            <a href="#" className="text-primary border-b-2 border-primary pb-unit">DASHBOARD</a>
            <a href="#" className="hover:text-on-surface transition-colors">MARKETS</a>
            <a href="#" className="hover:text-on-surface transition-colors">HISTORY</a>
            <a href="#" className="hover:text-on-surface transition-colors">RESOURCES</a>
          </nav>
        </div>

        <div className="flex items-center gap-stack-md">
          <div className="hidden lg:flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full border border-primary/20 h-8">
            <ShieldCheck className="w-3.5 h-3.5 text-primary" />
            <span className="text-[10px] font-bold text-primary uppercase tracking-tight">Verified Broker Gateway</span>
          </div>

          <div className="flex flex-col items-end mr-stack-sm">
            <span className="text-[11px] font-bold text-on-surface-variant tracking-widest uppercase">REAL ACCOUNT</span>
            <span className="text-[16px] font-mono font-bold text-primary">
              ${userData?.balance?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
            </span>
          </div>
          <button className="hidden sm:flex items-center gap-unit bg-primary-container text-on-primary-fixed px-4 py-2 rounded text-[12px] font-extrabold tracking-widest uppercase hover:brightness-110 active:scale-95 transition-all">
            <Wallet className="w-4 h-4" />
            DEPOSIT
          </button>
          <div className="h-8 w-px bg-slate-border mx-unit hidden sm:block"></div>
          <button className="w-10 h-10 rounded-full border border-slate-border flex items-center justify-center hover:bg-surface-container transition-colors">
            <Bell className="w-5 h-5 text-on-surface-variant" />
          </button>
          <button 
            onClick={onLogout}
            className="w-10 h-10 rounded-full border border-slate-border flex items-center justify-center hover:bg-red-500/10 hover:border-red-500/50 group transition-all"
          >
            <LogOut className="w-5 h-5 text-on-surface-variant group-hover:text-red-500" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Asset Selection */}
        <aside className="w-72 bg-slate-panel border-r border-slate-border flex flex-col hidden lg:flex">
          <div className="p-stack-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
              <input 
                type="text" 
                placeholder="Search assets..." 
                className="w-full bg-surface-container-lowest border border-slate-border rounded-lg py-2 pl-10 pr-4 text-[13px] focus:outline-none focus:border-primary-container"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {assets.map((asset) => (
              <button
                key={asset.id}
                onClick={() => setSelectedAsset(asset)}
                className={`w-full p-4 flex items-center justify-between border-b border-slate-border/50 hover:bg-surface-container transition-all text-left ${selectedAsset.id === asset.id ? 'bg-surface-container border-l-4 border-l-primary' : ''}`}
              >
                <div>
                  <div className="text-[14px] font-bold">{asset.name}</div>
                  <div className="text-[11px] text-on-surface-variant">Standard Brokerage</div>
                </div>
                <div className="text-right">
                  <div className="text-[14px] font-mono font-bold">{asset.price}</div>
                  <div className={`text-[11px] font-bold ${asset.trend === 'up' ? 'text-primary' : 'text-red-400'}`}>
                    {asset.change}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </aside>

        {/* Center - Chart & Activity */}
        <div className="flex-1 flex flex-col bg-surface-dim relative">
          {/* Asset Info Header */}
          <div className="p-stack-md flex items-center justify-between border-b border-slate-border">
            <div className="flex items-center gap-stack-md">
              <h2 className="text-[24px] font-headline font-bold">{selectedAsset.name}</h2>
              <div className={`px-unit py-1 rounded flex items-center gap-1 ${selectedAsset.trend === 'up' ? 'text-primary bg-primary/10' : 'text-red-400 bg-red-400/10'}`}>
                {selectedAsset.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                <span className="text-[12px] font-bold">{selectedAsset.change}</span>
              </div>
            </div>
            <div className="flex items-center gap-stack-md text-[13px] font-bold text-on-surface-variant">
              <span>H: 1.0882</span>
              <span>L: 1.0841</span>
            </div>
          </div>

          {/* Chart Container */}
          <div className="flex-1 p-stack-md min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f0b90b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f0b90b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262e3b" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="#4f4633" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  domain={['auto', 'auto']} 
                  stroke="#4f4633" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(val) => val.toFixed(4)}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151a21', border: '1px solid #262e3b', borderRadius: '8px' }}
                  itemStyle={{ color: '#f0b90b', fontFamily: 'JetBrains Mono' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#f0b90b" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorPrice)" 
                  animationDuration={300}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Recent Trades Table */}
          <div className="h-64 bg-slate-panel border-t border-slate-border p-stack-md overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[13px] font-bold uppercase tracking-widest flex items-center gap-2">
                <History className="w-4 h-4 text-primary" />
                RECENT POSITIONS
              </h3>
              <button className="text-[11px] font-bold text-primary hover:underline">VIEW ALL</button>
            </div>
            <div className="w-full text-left text-[12px]">
              <div className="grid grid-cols-5 text-on-surface-variant font-bold pb-2 border-b border-slate-border mb-2">
                <div>ASSET</div>
                <div>TYPE</div>
                <div>AMOUNT</div>
                <div>PROFIT</div>
                <div>TIME</div>
              </div>
              <div className="space-y-3 mt-4">
                {recentTrades.length > 0 ? recentTrades.map((trade, i) => (
                  <div key={trade.id || i} className="grid grid-cols-5 items-center font-bold">
                    <div className="flex items-center gap-2 text-on-surface-variant">
                      <div className="w-2 h-2 rounded-full bg-primary" />
                      {trade.assetName}
                    </div>
                    <div className={trade.type === 'CALL' ? 'text-primary' : 'text-red-400'}>{trade.type}</div>
                    <div className="font-mono text-on-surface-variant">${trade.amount}</div>
                    <div className={trade.status === 'win' ? 'text-primary' : 'text-on-surface-variant'}>
                      {trade.profit > 0 ? '+' : ''}${trade.profit.toFixed(2)}
                    </div>
                    <div className="text-on-surface-variant">
                      {trade.timestamp?.toDate ? trade.timestamp.toDate().toLocaleTimeString() : '...'}
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-8 text-on-surface-variant font-bold uppercase tracking-widest text-[10px]">
                    No positions found in history
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar - Trade Panel */}
        <aside className="w-80 bg-surface-container-low border-l border-slate-border flex flex-col p-container-padding gap-stack-lg">
          <div className="space-y-stack-md">
            <h3 className="text-[12px] font-bold text-on-surface-variant uppercase tracking-widest mb-unit">TRADE EXECUTION</h3>
            
            {/* Amount Field */}
            <div className="space-y-unit">
              <label className="text-[11px] font-bold text-on-surface-variant uppercase">INVESTMENT AMOUNT</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-primary-container">$</span>
                <input 
                  type="text" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-surface-container-lowest border border-slate-border rounded-lg py-4 pl-8 pr-4 font-mono text-[20px] font-bold text-on-surface focus:outline-none focus:border-primary-container"
                />
              </div>
            </div>

            {/* Expire Time Field */}
            <div className="space-y-unit">
              <label className="text-[11px] font-bold text-on-surface-variant uppercase">EXPIRATION TIME</label>
              <div className="grid grid-cols-4 gap-unit">
                {['1m', '5m', '15m', '1h'].map(t => (
                  <button 
                    key={t}
                    onClick={() => setDuration(t)}
                    className={`py-2 rounded text-[11px] font-bold border ${duration === t ? 'bg-primary/10 border-primary text-primary' : 'border-slate-border hover:bg-surface-container'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-center gap-stack-md">
            <div className="p-stack-md bg-primary/10 border border-primary/20 rounded-xl text-center space-y-unit">
              <div className="text-[11px] font-bold text-primary uppercase tracking-widest">POTENTIAL PROFIT (86%)</div>
              <div className="text-[32px] font-mono font-extrabold text-primary">
                +${(parseFloat(amount || '0') * 0.86).toFixed(2)}
              </div>
            </div>

            <button 
              onClick={() => handleTrade('CALL')}
              disabled={executing || (parseFloat(amount) > (userData?.balance || 0))}
              className="w-full bg-primary-container text-on-primary-fixed px-gutter py-6 rounded-xl flex items-center justify-between group hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-primary/10 disabled:opacity-50 disabled:scale-100"
            >
              <div className="text-left">
                <div className="text-[12px] font-bold uppercase tracking-widest opacity-80">HIGHER</div>
                <div className="text-[20px] font-extrabold">{executing ? 'PENDING...' : 'CALL'}</div>
              </div>
              <ChevronUp className="w-8 h-8 group-hover:translate-y-[-4px] transition-transform" />
            </button>

            <button 
              onClick={() => handleTrade('PUT')}
              disabled={executing || (parseFloat(amount) > (userData?.balance || 0))}
              className="w-full bg-[#ff4d4d] text-white px-gutter py-6 rounded-xl flex items-center justify-between group hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-red-500/10 disabled:opacity-50 disabled:scale-100"
            >
              <div className="text-left">
                <div className="text-[12px] font-bold uppercase tracking-widest opacity-80">LOWER</div>
                <div className="text-[20px] font-extrabold">{executing ? 'PENDING...' : 'PUT'}</div>
              </div>
              <ChevronDown className="w-8 h-8 group-hover:translate-y-[4px] transition-transform" />
            </button>
          </div>

          <div className="mt-auto pt-stack-md border-t border-slate-border flex flex-col gap-unit">
             <div className="flex items-center gap-2 text-center justify-center">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">TRADES SECURED BY AES-256</span>
             </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
