# Security Specification - TRADEX

## Data Invariants
1. A User document can only be created by the authenticated user matching the {userId}.
2. Initial balance must be set to a default value (e.g., 10000).
3. Trades must be stored under the user's specific subcollection.
4. Users can only read and write their own data.
5. `createdAt` and `userId` are immutable.

## The "Dirty Dozen" Payloads (Anti-Patterns to block)
1. **Unauthorized User Creation**: Attacker attempts to create a document in `/users/victimId`.
2. **Balance Spoofing**: User attempts to update their own balance to $1,000,000.
3. **Trade Hijacking**: Attacker attempts to read `/users/victimId/trades/tradeId`.
4. **Foreign Trade Injection**: Attacker attempts to create a trade in `/users/victimId/trades/`.
5. **Cross-User Asset Modification**: Attacker attempts to update a trade belonging to another user.
6. **Immutable Field Tampering**: User attempts to change `createdAt` timestamp.
7. **Negative Amount Trade**: User attempts to execute a trade with a negative amount.
8. **Shadow Field Injection**: User adds `isAdmin: true` to their user document.
9. **Overly Large Payload**: Sending a 1MB string in `assetName` to exhaust resources.
10. **State Skipping**: Updating a trade status from `pending` to `win` without system verification (if handled client-side, we should be careful; for this app, we'll allow client to update for demo purposes but limit reachable fields).
11. **Id Poisoning**: Using a 1.5KB string as a `{userId}`.
12. **Unverified Email Access**: Attempting to write data before verifying email (strict mode).

## Test Runner (Conceptual)
All payloads above should return `PERMISSION_DENIED` except where explicitly allowed for the authenticated owner.
/src/lib/firestore.rules.test.ts would be used in a real env.
